SINDAREALEST - ADMIN - SOURCE ONLY
Source Main SHA: cca1ff9be2ab7de4d89702f6dabf80d9bf3c7657
Contains Admin HTML, inline CSS/JavaScript and Admin service worker.
No images, fonts, logos, videos or other media binaries.
Note: Server API, schema and shared infrastructure remain in original repository and will be included in the complete export package.
