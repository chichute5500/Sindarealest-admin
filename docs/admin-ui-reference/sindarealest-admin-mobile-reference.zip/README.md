# SinDarealest ADMIN mobile reference

- `admin-mobile-reference.html`: self-contained HTML page with the full reference image embedded.
- `admin-mobile-reference.png`: standalone image asset.
- Treat the image as a visual mockup, not as evidence that the live application works.
- Visual target: light ice-blue / pearl-blue Liquid Glass, navy typography, restrained blue accents, albino crocodile texture.
- Preserve all existing backend behavior and test every admin flow after UI changes.
